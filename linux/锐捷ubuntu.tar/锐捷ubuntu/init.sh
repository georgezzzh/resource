sudo dpkg -i mentohust*.deb
sudo mkdir /etc/mentohust
sudo cp 8021x.exe W32N55.dll /etc/mentohust

