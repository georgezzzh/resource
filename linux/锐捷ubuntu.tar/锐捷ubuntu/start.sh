#d1表示动态分配dhcp v后面是版本号,-n指定网卡, -u为用户名, -p为密码
sudo mentohust -u20161xxxxx2 -p123456 -d1 -v6.82 -nenp2s0 &
